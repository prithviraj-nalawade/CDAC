import express from 'express';

const app = express();

app.get("/",(request,response)=>{
    response.send("Welcome to app");
});

app.get("/greet",(request,response)=>{
    response.status(200).send("Good Evening from GET");
});

app.post("/greet",(request,response)=>{
    response.status(200).send("Good Evening from POST");
});

app.get("/sum/:n1/:n2",(request,response)=>{
    const a = parseInt(request.params.n1);
    const b = parseInt(request.params.n2);
    const c = a + b;
    response.status(200).send({sum:c});
});

app.listen(4600,()=>{
    console.log('Server is running on port 4600');
});